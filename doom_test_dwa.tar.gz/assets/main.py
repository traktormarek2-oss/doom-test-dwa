import pygame
import math
import sys
import asyncio

# ==========================================
# USTAWIENIA GRY
# ==========================================
ROZDZIELCZOSC = (800, 600)
FPS = 60

SZYBKOSC_RUCHU = 0.08
SZYBKOSC_OBROTU = 0.05
ZASIEG_STRZALU = 8.0 

KOLOR_SUFITU = (40, 40, 40)
KOLOR_PODLOGI = (90, 90, 90)
KOLOR_BRONI = (150, 150, 150)
KOLOR_SCIANY_JASNY = (0, 200, 0)
KOLOR_SCIANY_CIEMNY = (0, 140, 0)
KOLOR_WROGA = (255, 0, 0)
ROZMIAR_WROGA = 0.5 

mapa = [
    [1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,0,0,1,0,1],
    [1,0,1,0,0,0,0,1,0,1],
    [1,0,0,0,0,1,0,0,0,1],
    [1,0,1,0,0,1,0,0,0,1],
    [1,0,1,1,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1]
]

# Zmienne globalne (stan i pozycja gracza)
pos_x, pos_y = 1.5, 1.5
dir_x, dir_y = -1.0, 0.0
plane_x, plane_y = 0.0, 0.66

wrogowie = [
    {"x": 7.5, "y": 7.5, "zywy": True, "timer_respawnu": 0},
    {"x": 4.5, "y": 3.5, "zywy": True, "timer_respawnu": 0}
]

animacja_strzalu = 0

# Definicje obszarów przycisków dotykowych na ekranie (Rect: x, y, szerokość, wysokość)
BTN_W = pygame.Rect(50, 420, 60, 60)
BTN_S = pygame.Rect(50, 500, 60, 60)
BTN_A = pygame.Rect(120, 460, 60, 60)
BTN_D = pygame.Rect(190, 460, 60, 60)
BTN_SHOOT = pygame.Rect(650, 440, 100, 100)

# ==========================================
# FUNKCJE POMOCNICZE
# ==========================================

def rysuj_bron(screen, strzela):
    szer = 120
    wys = 180
    
    odrzut_y = 30 if strzela > 0 else 0
    odrzut_x = 15 if strzela > 0 else 0
    
    x = ROZDZIELCZOSC[0] // 2 - szer // 2 + odrzut_x
    y = ROZDZIELCZOSC[1] - wys + odrzut_y
    
    pygame.draw.rect(screen, KOLOR_BRONI, (x, y, szer, wys))
    kolor_lufy = (255, 165, 0) if strzela > 0 else (20, 20, 20)
    pygame.draw.rect(screen, kolor_lufy, (x + 40, y - 30, 40, 80))
    
    pygame.draw.circle(screen, (0, 255, 0), (ROZDZIELCZOSC[0]//2, ROZDZIELCZOSC[1]//2), 3)

def rysuj_przyciski_mobilne(screen):
    # Półprzezroczyste przyciski ruchu i strzału na ekranie dla telefonów
    kolor_btn = (100, 100, 100)
    kolor_strzal = (200, 50, 50)
    
    for rect, tekst in [(BTN_W, "W"), (BTN_S, "S"), (BTN_A, "A"), (BTN_D, "D")]:
        pygame.draw.rect(screen, kolor_btn, rect, border_radius=10)
        pygame.draw.rect(screen, (200, 200, 200), rect, 2, border_radius=10)
        
    # Przycisk strzału
    pygame.draw.rect(screen, kolor_strzal, BTN_SHOOT, border_radius=20)
    pygame.draw.rect(screen, (255, 255, 255), BTN_SHOOT, 3, border_radius=20)

def strzal():
    global wrogowie
    ray_dir_x = dir_x
    ray_dir_y = dir_y
    
    for i in range(1, int(ZASIEG_STRZALU * 10)):
        sprawdz_x = pos_x + ray_dir_x * (i * 0.1)
        sprawdz_y = pos_y + ray_dir_y * (i * 0.1)
        
        if mapa[int(sprawdz_x)][int(sprawdz_y)] > 0:
            break 
            
        for wrog in wrogowie:
            if not wrog["zywy"]:
                continue
                
            odleglosc_do_wroga = math.sqrt((sprawdz_x - wrog["x"])**2 + (sprawdz_y - wrog["y"])**2)
            if odleglosc_do_wroga < ROZMIAR_WROGA / 1.5:
                wrog["zywy"] = False
                wrog["timer_respawnu"] = 300  # 300 klatek = ok. 5 sekund respawnu
                return 

# ==========================================
# GŁÓWNA PĘTLA ASYNCHRONICZNA
# ==========================================

async def main():
    global pos_x, pos_y, dir_x, dir_y, plane_x, plane_y, animacja_strzalu
    
    pygame.init()
    screen = pygame.display.set_mode(ROZDZIELCZOSC)
    pygame.display.set_caption("Python Raycaster - Web & Mobile")
    clock = pygame.time.Clock()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_SPACE and animacja_strzalu == 0:
                    strzal()
                    animacja_strzalu = 10 
            
            # Obsługa kliknięcia/dotknięcia przycisku strzału na ekranie
            if event.type == pygame.MOUSEBUTTONDOWN:
                if BTN_SHOOT.collidepoint(event.pos) and animacja_strzalu == 0:
                    strzal()
                    animacja_strzalu = 10

        if animacja_strzalu > 0:
            animacja_strzalu -= 1

        # Odliczanie czasu respawnu martwych wrogów
        for wrog in wrogowie:
            if not wrog["zywy"]:
                wrog["timer_respawnu"] -= 1
                if wrog["timer_respawnu"] <= 0:
                    wrog["zywy"] = True  

        pygame.draw.rect(screen, KOLOR_SUFITU, (0, 0, ROZDZIELCZOSC[0], ROZDZIELCZOSC[1]//2))
        pygame.draw.rect(screen, KOLOR_PODLOGI, (0, ROZDZIELCZOSC[1]//2, ROZDZIELCZOSC[0], ROZDZIELCZOSC[1]//2))

        ZBuffer = [0.0] * ROZDZIELCZOSC[0]

        # Renderowanie Ścian
        for x in range(ROZDZIELCZOSC[0]):
            camera_x = 2 * x / float(ROZDZIELCZOSC[0]) - 1
            ray_dir_x = dir_x + plane_x * camera_x
            ray_dir_y = dir_y + plane_y * camera_x

            map_x = int(pos_x)
            map_y = int(pos_y)

            delta_dist_x = abs(1 / ray_dir_x) if ray_dir_x != 0 else 1e30
            delta_dist_y = abs(1 / ray_dir_y) if ray_dir_y != 0 else 1e30
            hit = 0
            side = 0

            if ray_dir_x < 0:
                step_x = -1
                side_dist_x = (pos_x - map_x) * delta_dist_x
            else:
                step_x = 1
                side_dist_x = (map_x + 1.0 - pos_x) * delta_dist_x
            if ray_dir_y < 0:
                step_y = -1
                side_dist_y = (pos_y - map_y) * delta_dist_y
            else:
                step_y = 1
                side_dist_y = (map_y + 1.0 - pos_y) * delta_dist_y

            while hit == 0:
                if side_dist_x < side_dist_y:
                    side_dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    side_dist_y += delta_dist_y
                    map_y += step_y
                    side = 1
                if mapa[map_x][map_y] > 0:
                    hit = 1

            if side == 0:
                perp_wall_dist = (side_dist_x - delta_dist_x)
            else:
                perp_wall_dist = (side_dist_y - delta_dist_y)
            if perp_wall_dist == 0: perp_wall_dist = 0.001

            line_height = int(ROZDZIELCZOSC[1] / perp_wall_dist)
            draw_start = -line_height / 2 + ROZDZIELCZOSC[1] / 2
            if draw_start < 0: draw_start = 0
            draw_end = line_height / 2 + ROZDZIELCZOSC[1] / 2
            if draw_end >= ROZDZIELCZOSC[1]: draw_end = ROZDZIELCZOSC[1] - 1

            kolor = KOLOR_SCIANY_CIEMNY if side == 1 else KOLOR_SCIANY_JASNY
            pygame.draw.line(screen, kolor, (x, int(draw_start)), (x, int(draw_end)))

            ZBuffer[x] = perp_wall_dist

        # Renderowanie Przeciwników
        wrogowie_do_renderowania = []
        for wrog in wrogowie:
            if wrog["zywy"]:
                odleglosc = ((pos_x - wrog["x"])**2 + (pos_y - wrog["y"])**2)
                wrogowie_do_renderowania.append((odleglosc, wrog))
        wrogowie_do_renderowania.sort(reverse=True, key=lambda w: w[0])

        for dystans_kwadrat, wrog in wrogowie_do_renderowania:
            sprite_x = wrog["x"] - pos_x
            sprite_y = wrog["y"] - pos_y

            inv_det = 1.0 / (plane_x * dir_y - dir_x * plane_y)
            transform_x = inv_det * (dir_y * sprite_x - dir_x * sprite_y)
            transform_y = inv_det * (-plane_y * sprite_x + plane_x * sprite_y) 

            if transform_y <= 0:
                continue

            sprite_screen_x = int((ROZDZIELCZOSC[0] / 2) * (1 + transform_x / transform_y))

            v_move_screen = int(0.0 / transform_y)
            sprite_height = abs(int(ROZDZIELCZOSC[1] / (transform_y))) * ROZMIAR_WROGA
            draw_start_y = -sprite_height / 2 + ROZDZIELCZOSC[1] / 2 + v_move_screen
            draw_end_y = sprite_height / 2 + ROZDZIELCZOSC[1] / 2 + v_move_screen

            sprite_width = abs(int(ROZDZIELCZOSC[1] / (transform_y))) * ROZMIAR_WROGA
            draw_start_x = int(-sprite_width / 2 + sprite_screen_x)
            draw_end_x = int(sprite_width / 2 + sprite_screen_x)

            for stripe in range(max(0, draw_start_x), min(ROZDZIELCZOSC[0], draw_end_x)):
                if transform_y < ZBuffer[stripe]:
                    pygame.draw.line(screen, KOLOR_WROGA, (stripe, int(draw_start_y)), (stripe, int(draw_end_y)))

        # Nakładka broni i przyciski dotykowe na ekranie
        rysuj_bron(screen, animacja_strzalu)
        rysuj_przyciski_mobilne(screen)
        
        pygame.display.flip()

        # Sterowanie klawiaturą (komputer) ORAZ dotykiem (telefon / myszka)
        keys = pygame.key.get_pressed()
        
        # Sprawdzanie czy przytrzymywane są przyciski myszy / dotyku na ekranie
        m_pressed = pygame.mouse.get_pressed()[0]
        m_pos = pygame.mouse.get_pos()
        
        ruch_w = keys[pygame.K_w] or (m_pressed and BTN_W.collidepoint(m_pos))
        ruch_s = keys[pygame.K_s] or (m_pressed and BTN_S.collidepoint(m_pos))
        ruch_a = keys[pygame.K_a] or (m_pressed and BTN_A.collidepoint(m_pos))
        ruch_d = keys[pygame.K_d] or (m_pressed and BTN_D.collidepoint(m_pos))

        if ruch_w:
            if mapa[int(pos_x + dir_x * SZYBKOSC_RUCHU)][int(pos_y)] == 0: pos_x += dir_x * SZYBKOSC_RUCHU
            if mapa[int(pos_x)][int(pos_y + dir_y * SZYBKOSC_RUCHU)] == 0: pos_y += dir_y * SZYBKOSC_RUCHU
        if ruch_s:
            if mapa[int(pos_x - dir_x * SZYBKOSC_RUCHU)][int(pos_y)] == 0: pos_x -= dir_x * SZYBKOSC_RUCHU
            if mapa[int(pos_x)][int(pos_y - dir_y * SZYBKOSC_RUCHU)] == 0: pos_y -= dir_y * SZYBKOSC_RUCHU
        if ruch_a:
            old_dir_x = dir_x
            dir_x = dir_x * math.cos(SZYBKOSC_OBROTU) - dir_y * math.sin(SZYBKOSC_OBROTU)
            dir_y = old_dir_x * math.sin(SZYBKOSC_OBROTU) + dir_y * math.cos(SZYBKOSC_OBROTU)
            old_plane_x = plane_x
            plane_x = plane_x * math.cos(SZYBKOSC_OBROTU) - plane_y * math.sin(SZYBKOSC_OBROTU)
            plane_y = old_plane_x * math.sin(SZYBKOSC_OBROTU) + plane_y * math.cos(SZYBKOSC_OBROTU)
        if ruch_d:
            old_dir_x = dir_x
            dir_x = dir_x * math.cos(-SZYBKOSC_OBROTU) - dir_y * math.sin(-SZYBKOSC_OBROTU)
            dir_y = old_dir_x * math.sin(-SZYBKOSC_OBROTU) + dir_y * math.cos(-SZYBKOSC_OBROTU)
            old_plane_x = plane_x
            plane_x = plane_x * math.cos(-SZYBKOSC_OBROTU) - plane_y * math.sin(-SZYBKOSC_OBROTU)
            plane_y = old_plane_x * math.sin(-SZYBKOSC_OBROTU) + plane_y * math.cos(-SZYBKOSC_OBROTU)

        clock.tick(FPS)
        await asyncio.sleep(0) 

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
